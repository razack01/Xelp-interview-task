package com.example.userRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
