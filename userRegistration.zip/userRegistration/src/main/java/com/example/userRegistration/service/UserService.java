package com.example.userRegistration.service;

import com.example.userRegistration.model.Users;
import com.example.userRegistration.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UsersRepository usersRepository;

    public Users createUser(Users user) {

        return usersRepository.save(user);

    }

    public Users getUser(Users user) {
        Users users = usersRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
        return users==null?new Users():users;
    }
}
