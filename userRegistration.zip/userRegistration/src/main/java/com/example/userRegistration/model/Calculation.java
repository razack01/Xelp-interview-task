package com.example.userRegistration.model;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class Calculation {

    private double mean;
    private double median;
    private double mode;
    private int[] input;
}
