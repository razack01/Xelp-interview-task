package com.example.userRegistration.controller;

import com.example.userRegistration.model.Calculation;
import com.example.userRegistration.model.Users;
import com.example.userRegistration.service.CalculationService;
import com.example.userRegistration.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private CalculationService calculationService;

    @PostMapping("/create")
    public Users createUser(@RequestBody Users user){
        return userService.createUser(user);
    }

    @PostMapping("/getUser")
    public Users getUser(@RequestBody Users user){
        return userService.getUser(user);
    }

    @PostMapping("/getCalc")
    public Calculation getCalc(@RequestBody Calculation calculation){

        return calculationService.getCalc(calculation);
    }

}
